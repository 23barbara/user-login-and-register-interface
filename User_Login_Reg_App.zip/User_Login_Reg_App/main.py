from flask import Flask, render_template

app = Flask(__name__, template_folder='templates')
app.config['SECRET_KEY'] = 'secret'

# home page
@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html')

# login page 
@app.route("/login")
def login():
    return render_template('login.html')

# registration
@app.route("/register")
@app.route("/join")
def register():
    return render_template('register.html')


if __name__ == '__main__':
    app.run(debug=True)


